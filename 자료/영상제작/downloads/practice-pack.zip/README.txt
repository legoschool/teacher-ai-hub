﻿AI 디지털 영상 제작 실습자료

1. narration.txt를 Vrew의 대본 입력란에 붙여 넣습니다.
2. storyboard.csv를 보고 Canva에서 장면을 배치합니다.
3. subtitles.srt는 30초 예시이며 실제 음성 길이에 맞춰 수정합니다.
4. sprout.png는 교안용 AI 생성 이미지입니다. 실제 관찰 사진으로 표시하지 않습니다.
5. editing-example.mp4는 무음 편집 예시입니다. 생성형 영상 도구의 결과물이 아닙니다.
6. PDF에서 추출한 UI 이미지는 이 실습자료에 포함하지 않습니다.
